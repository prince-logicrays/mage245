<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Logicrays_ProductToCategoryManagement',
    __DIR__
);
