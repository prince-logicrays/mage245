<?php

namespace Logicrays\IncreaseQty\Plugin\Product\View\Type;

use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\CatalogInventory\Api\StockConfigurationInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class ConfigurablePlugin
{
    protected $jsonEncoder;
    protected $jsonDecoder;
    protected $stockRegistry;

    public function __construct(
        \Magento\Framework\Json\DecoderInterface $jsonDecoder,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        StockRegistryInterface $stockRegistry,
        StoreManagerInterface $storeManager,
        StockConfigurationInterface $stockConfiguration,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->jsonEncoder = $jsonEncoder;
        $this->jsonDecoder = $jsonDecoder;
        $this->stockRegistry = $stockRegistry;
        $this->storeManager = $storeManager;
        $this->stockConfiguration = $stockConfiguration;
        $this->scopeConfig = $scopeConfig;
    }

    public function afterGetJsonConfig(\Magento\ConfigurableProduct\Block\Product\View\Type\Configurable $subject, $result)
    {
        $result = $this->jsonDecoder->decode($result);
        $currentProduct = $subject->getProduct();

        if ($currentProduct->getName()) {
            $result['productName'] = $currentProduct->getName();
        }

        if ($currentProduct->getSku()) {
            $result['productSku'] = $currentProduct->getSku();
        }

        foreach ($subject->getAllowProducts() as $product) {

            $stockitem = $this->stockRegistry->getStockItem(
                $product->getId(),
                $product->getStore()->getWebsiteId()
            );

            $isStockManage = $this->isStockManage();
            if ($stockitem['use_config_manage_stock']) {
                if ($isStockManage) {
                    $adminStockManageQty = $stockitem->getQty();
                } else {
                    $adminStockManageQty = $stockitem->getQty().'_0';
                }
            } elseif ($stockitem['manage_stock']) {
                $adminStockManageQty = $stockitem->getQty();
            } else {
                $adminStockManageQty = $stockitem->getQty().'_0';
            }
            $quantities[$product->getId()] = $adminStockManageQty;

            $result['quantities'][$product->getId()] = $quantities;
            $result['names'][$product->getId()] = $product->getName();
            $result['skus'][$product->getId()] = $product->getSku();
        }
        return $this->jsonEncoder->encode($result);
    }

    /**
     * IsStockManage function
     *
     * @return boolean
     */
    public function isStockManage()
    {
        $storeId = $this->storeManager->getStore()->getStoreId();

        // Check global "Manage Stock" configuration first
        $isManageStockGlobal = $this->stockConfiguration->getManageStock();

        // Check store-specific configuration
        $isManageStockStore = $this->scopeConfig->getValue(
            'cataloginventory/item_options/manage_stock',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $storeId
        );

        // If Manage Stock is enabled either globally or for the specific store, return true
        return $isManageStockGlobal || $isManageStockStore;
    }
}
