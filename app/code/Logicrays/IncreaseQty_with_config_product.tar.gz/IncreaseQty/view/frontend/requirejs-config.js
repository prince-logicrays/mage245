var config = {
    map: {
       '*': {
          'Magento_Swatches/js/swatch-renderer':'Logicrays_IncreaseQty/js/swatch-renderer'
       }
    }
 };