<?php
namespace Logicrays\IncreaseQty\Block\Catalog\Product\View\Type\Bundle\Option;

class Radio extends \Magento\Bundle\Block\Catalog\Product\View\Type\Bundle\Option\Radio
{
    /**
     * @var string
     */
    protected $_template = 'Logicrays_IncreaseQty::catalog/product/view/type/bundle/option/radio.phtml';
}
