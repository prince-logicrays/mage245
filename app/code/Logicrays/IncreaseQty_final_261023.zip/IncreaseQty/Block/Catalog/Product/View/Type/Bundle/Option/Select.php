<?php
namespace Logicrays\IncreaseQty\Block\Catalog\Product\View\Type\Bundle\Option;

class Select extends \Magento\Bundle\Block\Catalog\Product\View\Type\Bundle\Option\Select
{
    /**
     * @var string
     */
    protected $_template = 'Logicrays_IncreaseQty::catalog/product/view/type/bundle/option/select.phtml';
}
